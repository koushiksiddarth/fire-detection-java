package com.fire.service;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;

/**
 * Java demo detector.
 *
 * IMPORTANT:
 * This starter project uses a deterministic image-color heuristic so it can run
 * immediately without a trained AI model. It is NOT a deep-learning model.
 *
 * For the final internship AI version, replace this service with an ONNX/DJL
 * or TensorFlow Java model trained on fire/non-fire images.
 */
@Service
public class FireDetectionService {

    public Map<String, Object> detect(MultipartFile file) throws Exception {
        BufferedImage image = ImageIO.read(file.getInputStream());
        if (image == null) {
            throw new IllegalArgumentException("Unsupported image format.");
        }

        long fireLike = 0;
        long total = (long) image.getWidth() * image.getHeight();
        int step = Math.max(1, Math.min(image.getWidth(), image.getHeight()) / 120);

        for (int y = 0; y < image.getHeight(); y += step) {
            for (int x = 0; x < image.getWidth(); x += step) {
                int rgb = image.getRGB(x, y);
                int r = (rgb >> 16) & 255;
                int g = (rgb >> 8) & 255;
                int b = rgb & 255;

                if (r > 180 && r > g * 1.25 && g > b * 1.15) {
                    fireLike++;
                }
            }
        }

        double ratio = (double) fireLike / Math.max(1, total / (step * step));
        boolean fire = ratio > 0.035;
        int confidence = (int) Math.round(Math.min(99, Math.max(70, 70 + ratio * 800)));

        Map<String, Object> result = new HashMap<>();
        result.put("result", fire ? "Fire Detected" : "No Fire");
        result.put("confidence", confidence);
        result.put("status", fire ? "Danger" : "Safe");
        result.put("filename", file.getOriginalFilename());
        result.put("note", "Demo Java detector. Replace with a trained deep-learning model for production.");
        return result;
    }
}
