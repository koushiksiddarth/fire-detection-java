# Fire Detection Using Java

A mobile/desktop-friendly Fire Detection web application built with **Java 17 + Spring Boot + HTML/CSS/JavaScript**.

## Run

Requirements:
- Java 17+
- Maven 3.9+

From the project folder:

```bash
mvn spring-boot:run
```

Open:

```text
http://localhost:8080
```

Or build a JAR:

```bash
mvn clean package
java -jar target/fire-detection-java-1.0.0.jar
```

## Important

The included `FireDetectionService` is a deterministic image-color heuristic so the project can run immediately. It is **not a trained deep-learning model**.

For a genuine AI/deep-learning version, replace that service with a trained fire/non-fire model using ONNX Runtime, DJL, or TensorFlow Java. The frontend and REST API can remain the same.

## Project structure

```text
src/main/java/com/fire/
  FireDetectionApplication.java
  controller/
    DetectionController.java
    PageController.java
  service/
    FireDetectionService.java

src/main/resources/
  templates/index.html
  static/style.css
  application.properties
```
